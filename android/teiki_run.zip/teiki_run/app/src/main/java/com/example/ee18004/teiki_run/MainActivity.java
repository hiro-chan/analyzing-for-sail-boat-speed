package com.example.ee18004.teiki_run;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView text_view = (TextView)findViewById(R.id.text_view);

        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            TextView text_view = (TextView)findViewById(R.id.text_view);
            String dispBody = "/";
            int i = 0;
            @Override
            public void run() {
                do{
                    dispBody = dispBody + String.valueOf(i) + "/";
                    i++;
                    text_view.setText(dispBody, TextView.BufferType.NORMAL);
                }while(i < 10);
            }
        },  0, 500);
        try {
            Thread.sleep(5000);   // 定期実行を待って休止
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        t.cancel();
    }
}
