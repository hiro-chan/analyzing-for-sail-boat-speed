package com.example.ee18004.practice1127;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.graphics.Color;
import android.view.View;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    private View mColorView;
    private SeekBar mSeekBarRed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mColorView = (View) findViewById(R.id.view_id);
        mSeekBarRed =(SeekBar) findViewById(R.id.seek_bar);
        ColorSet(mSeekBarRed);
        //SetView();

    }

    @Override
    protected void onResume() {
        super.onResume();
        SetView();

    }

    private void ColorSet(SeekBar colorValue){
        colorValue.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        //SetView();
                    }

                    public void onStopTrackingTouch(SeekBar seekBar) {
                        //SetView();
                    }
                }
        );
    }

    private void SetView(){

        mColorView.setBackgroundColor(Color.rgb(
                mSeekBarRed.getProgress(),50,50));
    }

}
