package com.example.ee18004.a1126;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread t1 = new MyThread();
        Thread t2 = new MyThread();
        t1.start();
        t2.start();
    }
    private class MyThread extends Thread {
        TextView text_view = (TextView)findViewById(R.id.text_view);
        String dispBody = "/";
        int i = 0;
        @Override
        public void run() {
            do{
                dispBody = dispBody + String.valueOf(i) + "/";
                i++;
            }while(i < 10);
            text_view.setText(dispBody, TextView.BufferType.NORMAL);
        }
    }
}
