package com.example.ee18004.sensor;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private SensorManager mSensorManager;
    private boolean mIsSensor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);


    }

    @Override
    protected void onResume() {
        super.onResume();
        // 照度センサー
        List<Sensor> sensors = mSensorManager.getSensorList(Sensor.TYPE_LIGHT);

        // センサマネージャへリスナーを登録(implements SensorEventListenerにより、thisで登録する)
        if (sensors.size() > 0) {
            Sensor sensor = sensors.get(0);
            mIsSensor = mSensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_FASTEST);
            /*
             * int  SENSOR_DELAY_FASTEST    get sensor data as fast as possible
             * int  SENSOR_DELAY_GAME       rate suitable for games
             * int  SENSOR_DELAY_NORMAL     rate (default) suitable for screen orientation changes
             * int  SENSOR_DELAY_UI         rate suitable for the user interface
             */
        }
    }



    // 通知タイミングはSENSOR_DELAY_FASTEST、変化があり次第即座に反応します
    public void onSensorChanged(SensorEvent event) {

        Log.v("Activity","Sensor.TYPE_LIGHT :" + String.valueOf(event.values[0]) ); //照度NexusOneの場合、10～10000程度で値が変わる

    }
}
