package com.example.ee18004.file_read_1126;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    InputStream is = null;
    BufferedReader br = null;
    String text = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView text_view = (TextView)findViewById(R.id.text_view);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                TextView text_view = (TextView)findViewById(R.id.text_view);
                // TODO: ここで処理を実行する
                try{
                    try{
                        is = getAssets().open("sample.txt");
                        br = new BufferedReader(new InputStreamReader(is));
                        String str;
                        while ((str = br.readLine()) != null) {
                            text += str + "\n";
                        }
                    }finally {
                        if (is != null) is.close();
                        if (br != null) br.close();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
                text_view.setText(text, TextView.BufferType.NORMAL);
            }
        }, 10000);
    }
}
