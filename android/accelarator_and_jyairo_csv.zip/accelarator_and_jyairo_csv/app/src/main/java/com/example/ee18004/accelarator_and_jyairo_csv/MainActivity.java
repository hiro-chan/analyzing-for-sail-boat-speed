package com.example.ee18004.accelarator_and_jyairo_csv;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity implements Runnable, SensorEventListener {
    SensorManager mSensorManager;
    Sensor mLinearAcc;
    Sensor mGyro;
    Handler mHandle;
    TextView tv;
    Handler h;
    float kx, ky, kz;
    float gx, gy, gz;

    //センサーを使うための準備
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button2 = findViewById(R.id.button2);
        final Button button3 = findViewById(R.id.button3);
        button3.setEnabled(false);  // STOPボタンをグレーアウトして無効化する

        mSensorManager =
                (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mLinearAcc = mSensorManager.
                getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        mGyro = mSensorManager.
                getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        LinearLayout ll = new LinearLayout(this);
        setContentView(ll);

        tv = new TextView(this);
        ll.addView(tv);

        h = new Handler();

        //h.postDelayed(this, 800);

        button2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
                mSensorManager.registerListener(MainActivity.this, mLinearAcc, SensorManager.SENSOR_DELAY_NORMAL);
                mSensorManager.registerListener(MainActivity.this, mGyro, SensorManager.SENSOR_DELAY_NORMAL);
                //mHandle.postDelayed(MainActivity.this, 800);
                button2.setEnabled(false);  // STARTボタンを無効化
                button3.setEnabled(true);   // STOPボタンを有効化
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
                mSensorManager.unregisterListener(MainActivity.this);
                //mHandle.removeCallbacks(MainActivity.this);
                button2.setEnabled(true);   // STARTボタンを有効化
                button3.setEnabled(false);  // STOPボタンを無効化
            }
        });


    }



    //センサーで得る値が変わるたびに行う動作
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION) {
            kx = event.values[0];
            ky = event.values[1];
            kz = event.values[2];
            Log.d("MainActivity",
                    "x=" + String.valueOf(event.values[0]) +
                            "y=" + String.valueOf(event.values[1]) +
                            "z=" + String.valueOf(event.values[2]));
            System.out.println("xの加速度 : " + kx
                    + "yの加速度 : " + ky
                    + "zの加速度 : " + kz);
            try {
                //出力先を作成する
                FileWriter fw = new FileWriter(getExternalFilesDir(null)+"/Kasokudo.csv", true);
                PrintWriter pw = new PrintWriter(new BufferedWriter(fw));

                //内容を指定する
                pw.print(kx );
                pw.print(",");
                pw.print(ky );
                pw.print(",");
                pw.print(kz );
                pw.println();

                //ファイルに書き出す
                pw.close();

                //終了メッセージを画面に出力する
                System.out.println("出力が完了しました。");

            } catch (IOException ex) {
                //例外時処理
                ex.printStackTrace();
            }

        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            gx = event.values[0];
            gy = event.values[1];
            gz = event.values[2];
            Log.d("MainActivity",
                    "X=" + String.valueOf(event.values[0]) +
                            "Y=" + String.valueOf(event.values[1]) +
                            "Z=" + String.valueOf(event.values[2]));
            System.out.println("Xのジャイロ ：" + gx
                    + "Yのジャイロ ：" + gy
                    + "Zのジャイロ :" + gz);
            try {
                //出力先を作成する
                FileWriter fw = new FileWriter(getExternalFilesDir(null)+"/Gyro.csv", true);
                PrintWriter pw = new PrintWriter(new BufferedWriter(fw));



                //内容を指定する

                pw.print(gx );
                pw.print(",");
                pw.print(gy );
                pw.print(",");
                pw.print(gz );
                pw.println();

                //ファイルに書き出す
                pw.close();

                //終了メッセージを画面に出力する
                System.out.println("出力が完了しました。");

            } catch (IOException ex) {
                //例外時処理
                ex.printStackTrace();
            }

        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(MainActivity.this);
        mHandle.removeCallbacks(MainActivity.this);
    }
    //データの更新時間間隔の設定
    @Override
    protected void onResume() {
        super.onResume();
    }


    //実機での表示

    @Override
    public void run() {
        tv.setText("Xの加速度 : " + kx*100 + "\n"
                + "Yの加速度 : " + ky*100 + "\n"
                + "Zの加速度 : " + kz*100 + "\n"
                + "Xのジャイロ　：" + gx + "\n"
                + "Yのジャイロ　：" + gy + "\n"
                + "Zのジャイロ　：" + gz + "\n"
        );
        h.postDelayed(this, 800);

    }


}
